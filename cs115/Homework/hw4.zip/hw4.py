'''
Created on Oct 3, 2016

@author: Alex Lu
'''
'I pledge my honor that I have abided by the Stevens Honor System'

def pascal_row(n):
    'returns row n of the pascal triangle in a list'
    def helper(n, actual):
        'returns the actual list after going through recursion'
        if n==0:
            return actual
        def addAd(lst,newlst):
            'adds the adjacent numbers together to form the next row of numbers. Also adds the number 1 to the beginning and end of the list'
            if len(lst)>1:
                newlst += [lst[0] + lst[1]]
                return addAd(lst[1:], newlst)
            if len(lst)==1:
                newlst+=[1]
                lst = newlst
            return [1] + lst
        actual = addAd(actual,[])
        return helper(n-1,actual)
    return helper(n,[1])



def pascal_triangle(n):
    'returns rows 0 to n of the pascal triangle in a list'
    def helper(n, actual,actual2):
        'returns the list of lists and adds the 0th row to the beginning'
        if n==0:
            return [[1]] + actual2
        def addAd(lst,newlst):
            'adds the adjacent numbers together to form the next row of numbers. Also adds the number 1 to the beginning and end of the list'
            if len(lst)>1:
                newlst += [lst[0] + lst[1]]
                return addAd(lst[1:], newlst)
            if len(lst)==1:
                newlst+=[1]
                lst = newlst
            return [1] + lst
        actual = addAd(actual,[])
        actual2 += [actual]
        return helper(n-1,actual,actual2)
    return helper(n,[1],[])

print(pascal_triangle(0))

